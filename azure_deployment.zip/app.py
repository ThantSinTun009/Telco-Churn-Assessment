from flask import Flask, render_template, request, flash, redirect, url_for
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Email config
EMAIL_ADDRESS = "thantsintun@parami.edu.mm"
EMAIL_PASSWORD = "bjaw mbcv rnnq gmuy"
RECEIVER_EMAIL = "youremail@gmail.com"

# Load trained pipeline
model = joblib.load("final_tuned_lgbm_pipeline.pkl")

# Home page
@app.route('/')
def home():
    return render_template("home.html")

# Prediction route
@app.route('/predict', methods=["GET", "POST"])
def predict():
    prediction = None
    probability = None

    if request.method == "POST":
        try:
            # Collect inputs from form
            data = {
                "gender": int(request.form["gender"]),
                "SeniorCitizen": int(request.form["SeniorCitizen"]),
                "Partner": int(request.form["Partner"]),
                "Dependents": int(request.form["Dependents"]),
                "tenure": float(request.form["tenure"]),
                "PhoneService": int(request.form["PhoneService"]),
                "MultipleLines": int(request.form["MultipleLines"]),
                "InternetService": request.form["InternetService"],
                "OnlineSecurity": int(request.form["OnlineSecurity"]),
                "OnlineBackup": int(request.form["OnlineBackup"]),
                "DeviceProtection": int(request.form["DeviceProtection"]),
                "TechSupport": int(request.form["TechSupport"]),
                "StreamingTV": int(request.form["StreamingTV"]),
                "StreamingMovies": int(request.form["StreamingMovies"]),
                "Contract": int(request.form["Contract"]),
                "PaperlessBilling": int(request.form["PaperlessBilling"]),
                "PaymentMethod": request.form["PaymentMethod"],
                "MonthlyCharges": float(request.form["MonthlyCharges"]),
                "TotalCharges": float(request.form["TotalCharges"])
            }

            df = pd.DataFrame([data])

            # --- Feature engineering (same as training) ---
            df["tenure_group"] = pd.cut(
                df["tenure"],
                bins=[0, 12, 24, 48, 72],
                labels=[0, 1, 2, 3]
            ).astype(int)

            df["charge_per_tenure"] = df["MonthlyCharges"] / (df["tenure"] + 1)
            df["avg_monthly_spend"] = df["TotalCharges"] / (df["tenure"] + 1)

            services = [
                'PhoneService','MultipleLines','OnlineSecurity','OnlineBackup',
                'DeviceProtection','TechSupport','StreamingTV','StreamingMovies'
            ]

            df["num_services"] = df[services].sum(axis=1)

            # Prediction
            y_prob = model.predict_proba(df)[:, 1][0]
            y_pred = 1 if y_prob > 0.35 else 0

            probability = round(y_prob * 100, 2)

            if y_pred == 1:
                prediction = "Churn"
            else:
                prediction = "No Churn"

        except Exception as e:
            print(e)
            prediction = "Error in input"

    return render_template("predict.html", prediction=prediction, probability=probability)


# Contact page
@app.route('/contact', methods=['GET'])
def contact():
    return render_template("contact.html")

@app.route('/contact', methods=['POST'])
def send_email():
    full_name = request.form['name']
    email = request.form['email']
    message = request.form['message']

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

        # Admin email
        msg_admin = MIMEMultipart()
        msg_admin['From'] = EMAIL_ADDRESS
        msg_admin['To'] = RECEIVER_EMAIL
        msg_admin['Subject'] = f"New Contact Message from {full_name}"
        msg_admin['Reply-To'] = email   

        body_admin = f"""
        New message received:

        Name: {full_name}
        Email: {email}

        Message:
        {message}
        """

        msg_admin.attach(MIMEText(body_admin, 'plain'))
        server.send_message(msg_admin)

        # Auto reply
        msg_user = MIMEMultipart()
        msg_user['From'] = EMAIL_ADDRESS
        msg_user['To'] = email
        msg_user['Subject'] = "We received your message"

        body_user = f"""
        Dear {full_name},

        Thank you for contacting us.
        We have received your message and will respond soon.

        Best regards,
        AI Team
        """

        msg_user.attach(MIMEText(body_user, 'plain'))
        server.send_message(msg_user)

        server.quit()

        flash("Your message has been sent successfully!", "success")
        return redirect(url_for('contact'))

    except Exception as e:
        print(e)
        flash("Something went wrong. Please try again.", "danger")
        return redirect(url_for('contact'))

if __name__ == '__main__':
    app.run(debug=True)